const TMCP = {
  version: "1.0.0",

  defaults: {
    enabled: true,
    autoAddOffer: true,
    noStartupInfos: true,
    autoAccessibility: true,
    noDiscoverMore: true,
    noVerifiedResale: true,
    speed: "normal",
    hideClicked: true
  },

  speeds: {
    fast: { tick: 80, tickWait: 300, continueWait: 250 },
    normal: { tick: 150, tickWait: 600, continueWait: 500 },
    slow: { tick: 250, tickWait: 1000, continueWait: 900 }
  },

  options: [
    {
      key: "autoAddOffer",
      group: "Auto Clicks",
      title: "Auto Add Multi-Offer Seats",
      desc: "Presses Add for you",
      info: "On events with more than one price offer, the side panel makes you press Add for each seat one by one. This presses it for you the moment it appears. With Hide auto-clicked button on in settings, the button stays invisible too.",
      icon: '<circle cx="11" cy="12.5" r="7.5"/><path d="M11 9v7M7.5 12.5h7"/><path d="M19 3.5v3.5M17.25 5.25h3.5"/>'
    },
    {
      key: "noStartupInfos",
      group: "Auto Clicks",
      title: "No Startup Infos",
      desc: "Closes startup info pop-ups",
      info: "Ticketmaster shows information pop-ups when a page or seat map loads. This dismisses them by pressing their confirm button, so they never get in your way.",
      icon: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 9.5h18"/><path d="M9.5 12.5l5 4M14.5 12.5l-5 4"/>'
    },
    {
      key: "autoAccessibility",
      group: "Auto Clicks",
      title: "Auto Accepts Accessibility Agreements",
      desc: "Ticks the box, then Continue",
      info: "When the accessibility agreement appears, this ticks its checkbox first, waits a moment, then presses Continue or Agree and Continue. The pause between the two steps follows the click speed in settings. It also dismisses the accessibility info pop-up that can show before it.",
      icon: '<circle cx="12" cy="4.8" r="1.8"/><path d="M5 8.6l7 1.3 7-1.3M12 9.9v4.1M12 14l-3 5.6M12 14l3 5.6"/>'
    },
    {
      key: "noDiscoverMore",
      group: "Hide From Page",
      title: "No Discover More",
      desc: "Hides the Discover More button",
      info: "Removes the Discover More button from the side panel so it can't be pressed by accident. It is only hidden, not deleted, and comes back as soon as you turn this off.",
      icon: '<circle cx="12" cy="12" r="8.5"/><path d="M14.9 9.1l-1.8 4-4 1.8 1.8-4z"/><path class="slash" d="M4 20L20 4"/>'
    },
    {
      key: "noVerifiedResale",
      group: "Hide From Page",
      title: "No Verified Resale Seats",
      desc: "Hides Verified Resale seats",
      info: "Finds every listing marked Verified Resale in the side panel and hides it. Normal tickets are left alone. Turn this off to show them again.",
      icon: '<path d="M12 3l7 2.8v5.4c0 4.2-2.9 7.6-7 9-4.1-1.4-7-4.8-7-9V5.8z"/><path d="M8.8 12l2.2 2.2 4.2-4.4"/><path class="slash" d="M4 20L20 4"/>'
    }
  ]
};
