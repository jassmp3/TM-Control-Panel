(() => {
  const FOOTER = '[class*="SidePanel__StyledFooter"] > div > button';
  const ACTIONS = '[class*="Modal__StyledActions"]';
  const HIDE = "data-tmcp-hide";

  let S = { ...TMCP.defaults };
  let loop = null;
  let scanTimer = null;

  const on = (key) => S.enabled && S[key];
  const speed = () => TMCP.speeds[S.speed] || TMCP.speeds.normal;

  const style = document.createElement("style");
  style.id = "tmcp-style";

  const mount = () => {
    if (!style.isConnected) (document.head || document.documentElement).appendChild(style);
  };

  const paintCss = () => {
    let css = `[${HIDE}]{display:none!important;}`;
    if (on("autoAddOffer") && S.hideClicked) {
      css += `${FOOTER}{opacity:0!important;pointer-events:none!important;}`;
    }
    style.textContent = css;
  };

  const press = (el) => {
    if (el && !el.disabled && el.dataset.tmcpDone !== "1") {
      el.dataset.tmcpDone = "1";
      el.click();
      return true;
    }
    return false;
  };

  const actionTarget = (box) =>
    box.querySelector('button[class*="indexstyles__StyledButton"]') ||
    box.querySelector(":scope > button");

  const modalKind = (box) => {
    const root = box.closest('[role="dialog"],[aria-modal="true"]') || box.parentElement;
    const text = (root ? root.textContent : "").toLowerCase();
    if (/accessib/.test(text) || /iazeFK/.test(String(box.className))) return "access";
    return "startup";
  };

  const agree = (cb) => {
    const now = Date.now();
    const sp = speed();
    if (!cb.checked) {
      const last = Number(cb.dataset.tmcpT || 0);
      if (now - last < sp.tickWait) return;
      const tries = Number(cb.dataset.tmcpN || 0);
      cb.dataset.tmcpT = now;
      cb.dataset.tmcpN = tries + 1;
      if (tries % 2 === 0) {
        cb.click();
      } else {
        const label =
          cb.closest("label") ||
          document.querySelector('label[for="modal-checkbox"]') ||
          cb.parentElement;
        if (label) label.click();
      }
      return;
    }
    if (!cb.dataset.tmcpOk) {
      cb.dataset.tmcpOk = now;
      return;
    }
    if (now - Number(cb.dataset.tmcpOk) >= sp.continueWait) {
      press(
        document.querySelector("#modalContent > div > div > button") ||
          document.querySelector("#modalContent button")
      );
    }
  };

  const tick = () => {
    if (!S.enabled) return;

    if (on("autoAddOffer")) press(document.querySelector(FOOTER));

    const cb = document.querySelector("#modal-checkbox");
    if (cb && on("autoAccessibility")) {
      agree(cb);
      return;
    }

    document.querySelectorAll(ACTIONS).forEach((box) => {
      const kind = modalKind(box);
      if ((kind === "access" && on("autoAccessibility")) || (kind === "startup" && on("noStartupInfos"))) {
        press(actionTarget(box));
      }
    });
  };

  const restore = (kind) => {
    document.querySelectorAll(`[${HIDE}="${kind}"]`).forEach((n) => n.removeAttribute(HIDE));
  };

  const isDiscoverMore = (el) => {
    const tag = el.tagName.toLowerCase();
    const role = (el.getAttribute("role") || "").toLowerCase();
    const label = [
      el.getAttribute("aria-label"),
      el.getAttribute("title"),
      el.getAttribute("data-testid"),
      el.getAttribute("data-bdd")
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();
    const text = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    const interactive =
      tag === "button" || tag === "a" || role === "button" || el.hasAttribute("tabindex") || /discover more/.test(label);
    return interactive && (/^discover more$/.test(text) || /discover more/.test(label));
  };

  const scanDiscoverMore = () => {
    document
      .querySelectorAll('button, a, [role="button"], [aria-label], [title], [data-testid], [data-bdd]')
      .forEach((el) => {
        if (!isDiscoverMore(el)) return;
        let target = el;
        const tag = el.tagName.toLowerCase();
        if (tag !== "button" && tag !== "a" && el.getAttribute("role") !== "button") {
          target = el.closest('button, a, [role="button"]') || el;
        }
        target.setAttribute(HIDE, "discover");
      });
  };

  const seatCount = (n) => (n.textContent.match(/\bSec\s*\w+/gi) || []).length;

  const findRow = (el) => {
    let row = el;
    let node = el;
    while (node.parentElement && node.parentElement !== document.body) {
      const parent = node.parentElement;
      if (seatCount(parent) > 1) break;
      if (/pay\s*in\s*4|we'?re all in/i.test(parent.textContent) && seatCount(parent) < 1) break;
      node = parent;
      if (seatCount(node) === 1) row = node;
    }
    return row;
  };

  const scanVerified = () => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (t) => (/verified resale/i.test(t.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT)
    });
    const hits = [];
    while (walker.nextNode()) hits.push(walker.currentNode.parentElement);
    hits.forEach((el) => {
      if (!el || el.closest(`[${HIDE}="verified"]`)) return;
      const row = findRow(el);
      if (!row || !/\bSec\s*\w+/i.test(row.textContent)) return;
      row.setAttribute(HIDE, "verified");
    });
  };

  const scan = () => {
    if (!document.body) return;
    if (on("noDiscoverMore")) scanDiscoverMore();
    else restore("discover");
    if (on("noVerifiedResale")) scanVerified();
    else restore("verified");
  };

  const apply = () => {
    paintCss();
    mount();
    clearInterval(loop);
    loop = setInterval(tick, speed().tick);
    tick();
    scan();
  };

  const schedule = () => {
    tick();
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, 100);
  };

  try {
    chrome.storage.local.get(TMCP.defaults, (v) => {
      S = { ...TMCP.defaults, ...v };
      apply();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      Object.keys(changes).forEach((k) => {
        S[k] = changes[k].newValue;
      });
      apply();
    });
  } catch (e) {
    apply();
  }

  new MutationObserver(schedule).observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });
})();
