function tmcpMountPanel(container, opts) {
  const fill = !!(opts && opts.fill);
  const float = !!(opts && opts.float);
  const svg = (inner) => `<svg viewBox="0 0 24 24">${inner}</svg>`;
  container.innerHTML = `<div class="shell${fill ? " fill" : ""}${float ? " float" : ""}">
<main class="panel">
  <header class="top">
    <div class="brand">
      <div class="logo"><i>tm</i></div>
      <div class="titles">
        <h1><span class="tm">tm</span> control panel</h1>
        <span class="by">By Jass</span>
      </div>
    </div>
    <div class="hbtns">
      <button class="hbtn" id="btnInfo" aria-label="Info">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5.5"/><circle cx="12" cy="7.6" r=".6" fill="currentColor"/></svg>
      </button>
      <button class="hbtn" id="btnSettings" aria-label="Settings">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      </button>
    </div>
  </header>

  <section class="card master" id="master">
    <div class="tile big">
      <svg viewBox="0 0 24 24"><path d="M12 3.5v8"/><path d="M6.7 6.9a7.5 7.5 0 1 0 10.6 0"/></svg>
    </div>
    <div class="txt">
      <div class="t big">Extension Enabled</div>
      <div class="d">Turn on or off all features</div>
    </div>
    <button class="power" id="power" role="switch" aria-checked="true" aria-label="Extension enabled">
      <span class="knob">
        <svg viewBox="0 0 24 24"><path d="M12 3.5v8"/><path d="M6.7 6.9a7.5 7.5 0 1 0 10.6 0"/></svg>
      </span>
    </button>
  </section>

  <div class="scroll">
    <section class="view" id="viewMain">
      <div class="options" id="groups"></div>
    </section>

    <section class="view" id="viewInfo" hidden>
      <h2>How each option works</h2>
      <div class="card infolist" id="infoList"></div>
    </section>

    <section class="view" id="viewSettings" hidden>
      <h2>Settings</h2>
      <div class="card list">
        <div class="row setrow">
          <div class="txt">
            <div class="t">Click speed</div>
            <div class="d">How quickly auto-clicks react</div>
          </div>
          <div class="seg" id="seg">
            <button data-speed="fast">Fast</button>
            <button data-speed="normal">Normal</button>
            <button data-speed="slow">Slow</button>
          </div>
        </div>
        <div class="row setrow">
          <div class="txt">
            <div class="t">Hide auto-clicked button</div>
            <div class="d">Keeps the Add button invisible</div>
          </div>
          <button class="sw" id="hideClicked" role="switch" aria-checked="true" aria-label="Hide auto-clicked button"><i></i></button>
        </div>
        <div class="row setrow">
          <div class="txt">
            <div class="t">Reset everything</div>
            <div class="d">Back to the default setup</div>
          </div>
          <button class="reset" id="reset">Reset</button>
        </div>
      </div>
      <p class="note">Settings apply to every tab and window in this browser.</p>
      <p class="ver" id="ver"></p>
    </section>
  </div>
</main>
</div>`;
  const $ = (s) => container.querySelector(s);

  let state = { ...TMCP.defaults };
  let current = "main";
  let resetTimer = null;

  const save = (patch) => {
    state = { ...state, ...patch };
    chrome.storage.local.set(patch);
    paint();
  };

  const rowHtml = (o) => `
    <div class="row">
      <div class="tile">${svg(o.icon)}</div>
      <div class="txt"><div class="t">${o.title}</div><div class="d">${o.desc}</div></div>
      <button class="sw" role="switch" data-key="${o.key}" aria-checked="true" aria-label="${o.title}"><i></i></button>
    </div>`;

  const renderMain = () => {
    const groups = {};
    TMCP.options.forEach((o) => (groups[o.group] = groups[o.group] || []).push(o));
    $("#groups").innerHTML = Object.entries(groups)
      .map(([g, items]) => `<h2>${g}</h2><div class="card list">${items.map(rowHtml).join("")}</div>`)
      .join("");
  };

  const renderInfo = () => {
    const master = `
      <div class="infoitem">
        <div class="tile">${svg('<path d="M12 3.5v8"/><path d="M6.7 6.9a7.5 7.5 0 1 0 10.6 0"/>')}</div>
        <div class="txt"><div class="t">Extension Enabled</div><div class="d">The main power button. Turn it off and every feature below stops working and the options go dull. Your choices are kept for when you turn it back on.</div></div>
      </div>`;
    const items = TMCP.options
      .map(
        (o) => `
      <div class="infoitem">
        <div class="tile">${svg(o.icon)}</div>
        <div class="txt"><div class="t">${o.title}</div><div class="d">${o.info}</div></div>
      </div>`
      )
      .join("");
    $("#infoList").innerHTML = master + items;
  };

  const paint = () => {
    $("#power").setAttribute("aria-checked", String(state.enabled));
    $("#groups").classList.toggle("dull", !state.enabled);
    container.querySelectorAll("#groups .sw").forEach((b) => b.setAttribute("aria-checked", String(!!state[b.dataset.key])));
    $("#hideClicked").setAttribute("aria-checked", String(!!state.hideClicked));
    container.querySelectorAll("#seg button").forEach((b) => b.classList.toggle("on", b.dataset.speed === state.speed));
  };

  const setView = (name) => {
    current = current === name ? "main" : name;
    $("#viewMain").hidden = current !== "main";
    $("#viewInfo").hidden = current !== "info";
    $("#viewSettings").hidden = current !== "settings";
    $("#master").hidden = current !== "main";
    $("#btnInfo").classList.toggle("active", current === "info");
    $("#btnSettings").classList.toggle("active", current === "settings");
    $(".scroll").scrollTop = 0;
  };

  $("#power").addEventListener("click", () => save({ enabled: !state.enabled }));

  $("#groups").addEventListener("click", (e) => {
    const b = e.target.closest(".sw");
    if (b) save({ [b.dataset.key]: !state[b.dataset.key] });
  });

  $("#btnInfo").addEventListener("click", () => setView("info"));
  $("#btnSettings").addEventListener("click", () => setView("settings"));

  $("#seg").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (b) save({ speed: b.dataset.speed });
  });

  $("#hideClicked").addEventListener("click", () => save({ hideClicked: !state.hideClicked }));

  $("#reset").addEventListener("click", (e) => {
    const btn = e.currentTarget;
    if (!btn.classList.contains("confirm")) {
      btn.classList.add("confirm");
      btn.textContent = "Sure?";
      resetTimer = setTimeout(() => {
        btn.classList.remove("confirm");
        btn.textContent = "Reset";
      }, 3000);
      return;
    }
    clearTimeout(resetTimer);
    btn.classList.remove("confirm");
    btn.textContent = "Reset";
    save({ ...TMCP.defaults });
  });

  $("#ver").textContent = `tm control panel ${TMCP.version}`;

  renderMain();
  renderInfo();
  paint();

  chrome.storage.local.get(TMCP.defaults, (v) => {
    state = { ...TMCP.defaults, ...v };
    paint();
  });

  const onStore = (changes, area) => {
    if (area !== "local") return;
    Object.keys(changes).forEach((k) => {
      state[k] = changes[k].newValue;
    });
    paint();
  };
  chrome.storage.onChanged.addListener(onStore);

  return () => chrome.storage.onChanged.removeListener(onStore);

}
