const TM = /^https?:\/\/([^/]+\.)?ticketmaster\.(com|co\.uk|ie|ca|com\.au|co\.nz)(\/|$|\?)/;

const route = (tabId, url) => {
  chrome.action.setPopup({ tabId, popup: url && TM.test(url) ? "" : "popup.html" }).catch(() => {});
};

const routeAll = () => {
  chrome.tabs.query({}, (tabs) => tabs.forEach((t) => route(t.id, t.url)));
};

chrome.runtime.onInstalled.addListener(routeAll);
chrome.runtime.onStartup.addListener(routeAll);

chrome.tabs.onUpdated.addListener((id, info, tab) => {
  if (info.url || info.status) route(id, tab.url);
});

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (t) => {
    if (!chrome.runtime.lastError && t) route(tabId, t.url);
  });
});

chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.sendMessage(tab.id, { type: "tmcp-toggle" }, (res) => {
    const err = chrome.runtime.lastError;
    if (err || !res) {
      chrome.action.setPopup({ tabId: tab.id, popup: "popup.html" }).then(() => {
        if (chrome.action.openPopup) chrome.action.openPopup().catch(() => {});
      });
    }
  });
});
