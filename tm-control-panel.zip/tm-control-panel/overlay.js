(() => {
  if (window.top !== window) return;

  let host = null;
  let dispose = null;

  const close = () => {
    if (dispose) dispose();
    if (host) host.remove();
    host = null;
    dispose = null;
    document.removeEventListener("mousedown", onOutside, true);
    document.removeEventListener("keydown", onKey, true);
  };

  const onOutside = (e) => {
    if (host && !e.composedPath().includes(host)) close();
  };

  const onKey = (e) => {
    if (e.key === "Escape") close();
  };

  const open = async () => {
    let css = "";
    try {
      css = await fetch(chrome.runtime.getURL("popup.css")).then((r) => r.text());
    } catch (e) {
      return;
    }
    host = document.createElement("div");
    host.id = "tmcp-host";
    host.style.cssText = "all:initial;position:fixed;top:10px;right:12px;z-index:2147483647;";
    const root = host.attachShadow({ mode: "open" });
    const st = document.createElement("style");
    st.textContent = css.replace(/html,\s*body\s*\{[^}]*\}/, "");
    const mount = document.createElement("div");
    root.append(st, mount);
    dispose = tmcpMountPanel(mount, { float: true });
    document.documentElement.appendChild(host);
    document.addEventListener("mousedown", onOutside, true);
    document.addEventListener("keydown", onKey, true);
  };

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "tmcp-toggle") {
      if (host) close();
      else open();
      sendResponse({ ok: true });
    }
  });
})();
